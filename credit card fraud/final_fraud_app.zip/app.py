from flask import Flask, render_template, request, redirect, url_for, session, flash
import matplotlib.pyplot as plt
import pandas as pd
import joblib
import os

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Hardcoded multiple users
users = {
    "client1": "pass123",
    "client2": "secure456",
    "admin": "adminpass"
}

model = joblib.load('fraud_model.pkl')

def rule_based_fraud_check(df, credit_limit):
    if df['Amount'].sum() > credit_limit:
        return True
    if any(df['Amount'] > 0.8 * credit_limit):
        return True
    if df['Category'].value_counts().get('Entertainment', 0) >= 4:
        return True
    return False

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        client_id = request.form['client_id']
        password = request.form['password']
        if client_id in users and users[client_id] == password:
            session['user'] = client_id
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/')
def index():
    if 'user' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'user' not in session:
        return redirect(url_for('login'))

    name = request.form['name']
    bank = request.form['bank']
    last4 = request.form['last4']
    credit_limit = float(request.form['limit'])
    file = request.files['file']
    df = pd.read_csv(file)

    if not {'Amount', 'Category'}.issubset(df.columns):
        return "CSV must contain 'Amount' and 'Category'."

    rule_flag = rule_based_fraud_check(df, credit_limit)

    X = pd.get_dummies(df['Category'])
    for col in ['Food', 'Bills', 'Personal', 'Entertainment']:
        if col not in X:
            X[col] = 0
    X['Amount'] = df['Amount']
    X.columns = [str(col) for col in X.columns]
    pred = model.predict([X.sum()])[0]
    fraud = rule_flag or pred == 1

    os.makedirs("static", exist_ok=True)
    category_summary = df.groupby("Category")["Amount"].sum()
    plt.figure(figsize=(5, 5))
    plt.pie(category_summary, labels=category_summary.index, autopct='%1.1f%%', startangle=140)
    plt.title("Spending by Category")
    plt.tight_layout()
    plt.savefig("static/pie_chart.png")
    plt.close()

    return render_template('result.html',
        name=name,
        bank=bank,
        last4=last4,
        limit=credit_limit,
        total=df['Amount'].sum(),
        category_summary=category_summary.to_dict(),
        fraud=fraud
    )

if __name__ == '__main__':
    app.run(debug=True)
